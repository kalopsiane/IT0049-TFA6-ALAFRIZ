<?php

namespace Database\Seeders;

use App\Models\Customer;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::create([
            'username' => 'admin',
            'full_name' => 'Admin User',
            'password' => Hash::make('password'),
        ]);

        User::create([
            'username' => 'staff01',
            'full_name' => 'Sunraku',
            'password' => Hash::make('password'),
        ]);

        User::create([
            'username' => 'staff02',
            'full_name' => 'Psyger 0',
            'password' => Hash::make('password'),
        ]);

        User::create([
            'username' => 'cashier01',
            'full_name' => 'Arthur Pencilgon',
            'password' => Hash::make('password'),
        ]);

        User::create([
            'username' => 'cashier02',
            'full_name' => 'Katzo',
            'password' => Hash::make('password'),
        ]);

        Customer::create([
            'full_name' => 'Emul',
            'email' => 'emul@example.com',
            'phone' => '09171234567',
        ]);

        Customer::create([
            'full_name' => 'Vysache',
            'email' => 'vysache@example.com',
            'phone' => '09181234567',
        ]);

        Customer::create([
            'full_name' => 'Bilac',
            'email' => 'bilac@example.com',
            'phone' => '09191234567',
        ]);

        Customer::create([
            'full_name' => 'Lycagon',
            'email' => 'lycagon@example.com',
            'phone' => '09201234567',
        ]);

        Customer::create([
            'full_name' => 'Wethermon',
            'email' => 'wethermon@example.com',
            'phone' => '09211234567',
        ]);
    }
}