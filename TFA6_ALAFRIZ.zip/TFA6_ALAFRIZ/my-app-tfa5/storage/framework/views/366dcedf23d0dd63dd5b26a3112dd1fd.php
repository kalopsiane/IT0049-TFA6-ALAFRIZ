<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Page</title>
</head>
<body>
    <h1><?php echo e($course); ?></h1>

    <p>This is the About page.</p>
</body>
</html><?php /**PATH C:\Users\Ane\Herd\my-app\resources\views/about.blade.php ENDPATH**/ ?>