<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel POS</title>
</head>
<body>
    <nav>
        <a href="/">Home</a> |
        <a href="/about">About</a> |
        <a href="/customers">Customers</a> |
        <a href="/users">Users</a>
    </nav>

    <h1>Laravel POS Application</h1>

    <p>Welcome to the Laravel POS Foundations application.</p>
    <p>This system contains customer and user account pages.</p>
</body>
</html><?php /**PATH C:\Users\Ane\Herd\my-app-tfa5\resources\views/home.blade.php ENDPATH**/ ?>