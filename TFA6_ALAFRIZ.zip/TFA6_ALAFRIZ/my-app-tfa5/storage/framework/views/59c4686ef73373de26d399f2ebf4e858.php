<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Details</title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p>Task ID: <?php echo e($id); ?></p>
</body>
</html><?php /**PATH C:\Users\Ane\Herd\my-app\resources\views/task.blade.php ENDPATH**/ ?>