<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Page</title>
</head>
<body>
    <nav>
        <a href="/">Home</a> |
        <a href="/about">About</a> |
        <a href="/customers">Customers</a> |
        <a href="/users">Users</a>
    </nav>

    <h1><?php echo e($course); ?></h1>
    <p><?php echo e($module); ?></p>
    <p>This is the About page.</p>
</body>
</html><?php /**PATH C:\Users\Ane\Herd\my-app-tfa5\resources\views/about.blade.php ENDPATH**/ ?>