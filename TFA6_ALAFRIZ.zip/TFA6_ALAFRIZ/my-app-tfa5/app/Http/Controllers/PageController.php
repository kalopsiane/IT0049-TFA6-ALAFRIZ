<?php

namespace App\Http\Controllers;

class PageController extends Controller
{
    public function index()
    {
        return view('home');
    }

    public function about()
    {
        $data = [
            'course' => 'Web System Technologies',
            'module' => 'Laravel POS Foundations',
        ];

        return view('about', $data);
    }

    public function task($id)
    {
        return view('task', [
            'id' => $id,
            'title' => 'Buy groceries',
        ]);
    }
}
